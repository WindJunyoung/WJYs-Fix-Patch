package cn.blockforge.generated.minecraft1211fa8fc6.mixins;

import net.minecraft.block.BlockState;
import net.minecraft.block.DragonEggBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(DragonEggBlock.class)
abstract class DragonEggTeleportMixin {
    @Unique
    private BlockPos cachedStartPos;

    // 注入 teleport 方法头部，记录起点
    @Inject(
            method = "teleport",
            at = @At("HEAD")
    )
    private void wjys$captureStart(BlockState state, World world, BlockPos pos, CallbackInfo ci) {
        // 只在客户端记录起点，服务端不处理粒子
        if (!world.isClient()) return;
        cachedStartPos = pos.toImmutable();
    }

    // 注入 teleport 尾部，此时龙蛋已经瞬移完成，pos 是【新位置】
    @Inject(
            method = "teleport",
            at = @At("TAIL")
    )
    private void wjys$spawnTeleportParticles(BlockState state, World world, BlockPos newPos, CallbackInfo ci) {
        // 只在客户端生成粒子
        if (!world.isClient() || cachedStartPos == null) return;

        Vec3d start = cachedStartPos.toCenterPos();
        Vec3d end = newPos.toCenterPos();

        // 生成连线粒子
        for (int i = 0; i < 16; i++) {
            double t = i / 15.0;
            double x = start.x + (end.x - start.x) * t;
            double y = start.y + (end.y - start.y) * t;
            double z = start.z + (end.z - start.z) * t;

            // 使用客户端粒子管理器，确保所有客户端都能看到粒子
            MinecraftClient.getInstance().particleManager.addParticle(
                    ParticleTypes.PORTAL,
                    x, y, z,
                    0, 0, 0
            );
        }
        cachedStartPos = null;
    }
}