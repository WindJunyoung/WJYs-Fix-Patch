package cn.blockforge.generated.minecraft1211fa8fc6.mixins;

import net.minecraft.class_1937;
import net.minecraft.class_2328;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2328.class)
abstract class DragonEggTeleportMixin {
    @Unique
    private class_2338 cachedStartPos;

    // 注入 teleport 方法头部，记录起点
    @Inject(
            method = "teleport",
            at = @At("HEAD")
    )
    private void wjys$captureStart(class_2680 state, class_1937 world, class_2338 pos, CallbackInfo ci) {
        // 只在客户端记录起点，服务端不处理粒子
        if (!world.method_8608()) return;
        cachedStartPos = pos.method_10062();
    }

    // 注入 teleport 尾部，此时龙蛋已经瞬移完成，pos 是【新位置】
    @Inject(
            method = "teleport",
            at = @At("TAIL")
    )
    private void wjys$spawnTeleportParticles(class_2680 state, class_1937 world, class_2338 newPos, CallbackInfo ci) {
        // 只在客户端生成粒子
        if (!world.method_8608() || cachedStartPos == null) return;

        class_243 start = cachedStartPos.method_46558();
        class_243 end = newPos.method_46558();

        // 生成连线粒子
        for (int i = 0; i < 16; i++) {
            double t = i / 15.0;
            double x = start.field_1352 + (end.field_1352 - start.field_1352) * t;
            double y = start.field_1351 + (end.field_1351 - start.field_1351) * t;
            double z = start.field_1350 + (end.field_1350 - start.field_1350) * t;

            // 使用客户端粒子管理器，确保所有客户端都能看到粒子
            class_310.method_1551().field_1713.method_3056(
                    class_2398.field_11214,
                    x, y, z,
                    0, 0, 0
            );
        }
        cachedStartPos = null;
    }
}