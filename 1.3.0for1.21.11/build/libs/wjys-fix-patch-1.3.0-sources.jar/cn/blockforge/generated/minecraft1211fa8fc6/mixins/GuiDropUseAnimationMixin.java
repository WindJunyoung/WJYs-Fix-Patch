package cn.blockforge.generated.minecraft1211fa8fc6.mixins;

import cn.blockforge.generated.minecraft1211fa8fc6.BugFix;
import cn.blockforge.generated.minecraft1211fa8fc6.BugFixConfig;
import net.minecraft.class_1268;
import net.minecraft.class_310;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_746.class)
public abstract class GuiDropUseAnimationMixin {
    @Shadow
    protected class_310 client;

    @Inject(
            method = "swingHand(Lnet/minecraft/util/Hand;)V",
            at = @At("HEAD"),
            cancellable = true,
            require = 0
    )
    private void wjys$cancelGuiDropSwingHand(class_1268 hand, CallbackInfo ci) {
        if (!BugFixConfig.isEnabled(BugFix.MC302687)) return;
        if (client.field_1755 != null) {
            ci.cancel();
        }
    }
}
