package cn.blockforge.generated.minecraft1211fa8fc6.mixins;

import cn.blockforge.generated.minecraft1211fa8fc6.BugFix;
import cn.blockforge.generated.minecraft1211fa8fc6.BugFixConfig;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1646;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_1646.class)
public abstract class VillagerExperienceCarryOverMixin {

    @Shadow
    private boolean levelingUp;

    @Shadow
    private int levelUpTimer;

    @Shadow
    private boolean canLevelUp() {
        return false;
    }

    @Shadow
    private void levelUp(class_3218 world) {
    }

    @Shadow
    private void sendOffersToCustomer() {
    }

    @Inject(
            method = "tick()V",
            at = @At("TAIL"),
            require = 0
    )
    @SuppressWarnings("ConstantConditions")
    private void wjys$carryOverOverflowExperience(CallbackInfo ci) {
        if (!BugFixConfig.isEnabled(BugFix.MC265423)) {
            return;
        }
        try {
            // 强转为目标类，调用公共方法 getEntityWorld() 获取世界实例
            class_1646 self = (class_1646)(Object)this;
            class_1937 world = self.method_73183();

            if (world instanceof class_638 || this.levelingUp || this.levelUpTimer > 0) {
                return;
            }

            class_3218 serverWorld = (class_3218) world;
            int carried = 0;
            while (carried < 5 && this.canLevelUp()) {
                this.levelUp(serverWorld);
                // 强转后调用 addStatusEffect 方法
                self.method_6092(new class_1293(class_1294.field_5924, 200, 0));
                carried++;
            }

            if (carried > 0) {
                this.sendOffersToCustomer();
            }
        } catch (Throwable t) {
            BugFixConfig.LOGGER.warn("[MC-265423] 村民经验溢出结转修复注入失败，已回退原版行为", t);
        }
    }
}
